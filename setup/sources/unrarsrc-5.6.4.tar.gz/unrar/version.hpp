#define RARVER_MAJOR     5
#define RARVER_MINOR    60
#define RARVER_BETA      4
#define RARVER_DAY      14
#define RARVER_MONTH     5
#define RARVER_YEAR   2018
